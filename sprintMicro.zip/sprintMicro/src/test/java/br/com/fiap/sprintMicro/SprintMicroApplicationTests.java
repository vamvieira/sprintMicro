package br.com.fiap.sprintMicro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprintMicroApplicationTests {

	@Test
	void contextLoads() {
	}

}
